from flask import Flask, render_template, request, jsonify, session, redirect, url_for
import random

app = Flask(__name__)
app.secret_key = "mechfinder_secret_key_2024"

# --- DATA ---
login_details = {
    "m.chandu": 12, "m.venu": 1245, "m.rakesh": 8723,
    "m.masthan": 173, "m.fayaz": 284
}

services_cost = {
    "engine services": 250, "oil services": 50, "fluid services": 70,
    "brake services": 120, "transmission": 300, "electrical system services": 180,
    "suspension": 220, "steering": 160, "tire services": 100,
    "cooling system services": 140, "exhaust system service": 130,
    "general services": 90, "body services": 200, "miscellaneous repairs": 80
}

mechanics_by_address = {
    "guntur": {"name": "Ravan", "phone": "845851XXXX"},
    "vijayawada": {"name": "Kiran", "phone": "756559XXXX"},
    "pedhakakani": {"name": "Vijay", "phone": "929565XXXX"},
    "kakani": {"name": "Ravi", "phone": "826545XXXX"},
    "namburu": {"name": "Ajay", "phone": "687454XXXX"},
    "mangalagiri": {"name": "Vishnu", "phone": "934851XXXX"},
}

registered_mechanics = []

# --- ROUTES ---
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        data = request.get_json()
        username = data.get("username", "").lower()
        password = int(data.get("password", 0))
        if username in login_details and login_details[username] == password:
            session["user"] = username
            return jsonify({"success": True})
        return jsonify({"success": False, "message": "Invalid username or password"})
    return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        data = request.get_json()
        name = data.get("name")
        address = data.get("address")
        phone = data.get("phone", "")
        mechanic_type = data.get("type")

        if len(phone) != 10 or not phone.isdigit():
            return jsonify({"success": False, "message": "Phone number must be 10 digits"})

        entry = {"name": name, "address": address, "phone": phone, "type": mechanic_type}

        if mechanic_type == "shop":
            license_no = data.get("license", "")
            if len(license_no) != 16:
                return jsonify({"success": False, "message": "License must be 16 characters"})
            entry["license"] = license_no
            entry["shop_address"] = data.get("shop_address", "")

        elif mechanic_type == "company":
            entry["company_address"] = data.get("company_address", "")
            entry["company_id"] = data.get("company_id", "")
            agent_phone = data.get("agent_phone", "")
            if len(agent_phone) != 10:
                return jsonify({"success": False, "message": "Agent phone must be 10 digits"})
            entry["agent_phone"] = agent_phone

        elif mechanic_type == "freelance":
            entry["service_name"] = data.get("service_name", "")
            entry["service_amount"] = data.get("service_amount", 0)

        registered_mechanics.append(entry)
        return jsonify({"success": True, "message": "Registration successful!"})
    return render_template("register.html")

@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect(url_for("login"))
    return render_template("dashboard.html", user=session["user"])

@app.route("/services", methods=["GET", "POST"])
def services():
    if request.method == "POST":
        data = request.get_json()
        selected = data.get("services", [])
        total = sum(services_cost.get(s.lower(), 0) for s in selected)
        address = data.get("address", "").lower()
        mechanic = mechanics_by_address.get(address)
        booking_id = "ID-" + "".join([str(random.randint(0, 9)) for _ in range(5)])
        if mechanic:
            return jsonify({
                "success": True,
                "id": booking_id,
                "services": selected,
                "total": total,
                "mechanic": mechanic,
                "address": address.title()
            })
        return jsonify({"success": False, "message": f"No mechanic available in {address.title()}"})
    return render_template("services.html", services=list(services_cost.keys()), costs=services_cost)

@app.route("/map")
def map_page():
    locations = [{"city": k.title(), "mechanic": v["name"], "phone": v["phone"]} for k, v in mechanics_by_address.items()]
    return render_template("map.html", locations=locations)

@app.route("/profile")
def profile():
    if "user" not in session:
        return redirect(url_for("login"))
    return render_template("profile.html", user=session["user"])

@app.route("/report", methods=["GET", "POST"])
def report():
    if request.method == "POST":
        data = request.get_json()
        address = data.get("address", "").lower()
        mechanic = mechanics_by_address.get(address)
        booking_id = "ID-" + "".join([str(random.randint(0, 9)) for _ in range(5)])
        if mechanic:
            return jsonify({"success": True, "id": booking_id, "mechanic": mechanic, "address": address.title()})
        return jsonify({"success": False, "message": f"No mechanic available in {address.title()}"})
    return render_template("report.html")

@app.route("/settings", methods=["GET", "POST"])
def settings():
    if request.method == "POST":
        data = request.get_json()
        rating = float(data.get("rating", 0))
        if 1.0 <= rating <= 2.0:
            msg = "Thanks for your feedback. We'll improve!"
        elif 2.0 < rating <= 4.0:
            msg = "Nice! Thanks for rating us."
        else:
            msg = "Amazing! You're our top fan! ⭐"
        return jsonify({"success": True, "message": msg})
    return render_template("settings.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True)
