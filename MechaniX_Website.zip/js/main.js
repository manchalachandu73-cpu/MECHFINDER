/* ════════════════════════════════════
   MechaniX — Shared JS (main.js)
   ════════════════════════════════════ */

// ── DATA ──
const MX = {
  services: {
    "engine services":   250,
    "oil services":       50,
    "fluid services":     70,
    "brake services":    120,
    "transmission":      300,
    "electrical system": 180,
    "suspension":        220,
    "steering":          160,
    "tire services":     100,
    "cooling system":    140,
    "exhaust system":    130,
    "general services":   90,
    "body services":     200,
    "misc repairs":       80
  },

  mechanicsBike: {
    guntur:      { name: "Ravan",   phone: "845851XXXX" },
    vijawada:    { name: "Kiran",   phone: "756559XXXX" },
    pedhakakani: { name: "Vijay",   phone: "929565XXXX" },
    kakani:      { name: "Ravi",    phone: "826545XXXX" },
    namburu:     { name: "Ajay",    phone: "687454XXXX" },
    mangalagir:  { name: "Vishnu",  phone: "934851XXXX" }
  },

  mechanicsOther: {
    guntur:      { name: "Masthan", phone: "849851XXXX" },
    vijawada:    { name: "Gambhir", phone: "786559XXXX" },
    pedhakakani: { name: "Arjun",   phone: "929650XXXX" },
    kakani:      { name: "Praveen", phone: "826545XXXX" },
    namburu:     { name: "Pavan",   phone: "687454XXXX" },
    mangalagir:  { name: "Shekhar", phone: "987751XXXX" }
  },

  users: {
    "m.chandu":  12,
    "m.venu":    1245,
    "m.rakesh":  8723,
    "m.masthan": 173,
    "m.fayaz":   284
  },

  areas: ["guntur","vijawada","pedhakakani","kakani","namburu","mangalagir"],
  areaLabels: {
    guntur:"Guntur", vijawada:"Vijayawada",
    pedhakakani:"Pedhakakani", kakani:"Kakani",
    namburu:"Namburu", mangalagir:"Mangalagiri"
  }
};

// ── UTILITIES ──
function genID() {
  return 'ID-' + Array.from({length:5}, () => Math.floor(Math.random()*10)).join('');
}

function showAlert(id, type, msg) {
  const el = document.getElementById(id);
  if (!el) return;
  el.className = 'alert ' + type + ' show';
  el.textContent = msg;
  el.style.display = 'block';
}

function hideAlert(id) {
  const el = document.getElementById(id);
  if (el) { el.style.display = 'none'; el.className = 'alert'; }
}

function validatePassword(pw) {
  return pw.length >= 8 && /[A-Z]/.test(pw) && /[a-z]/.test(pw) && /[0-9]/.test(pw);
}

function checkStrength(pw, fillId, labelId) {
  const fill  = document.getElementById(fillId);
  const label = document.getElementById(labelId);
  if (!fill || !label) return;
  let score = 0;
  if (pw.length >= 8)    score++;
  if (/[A-Z]/.test(pw))  score++;
  if (/[a-z]/.test(pw))  score++;
  if (/[0-9]/.test(pw))  score++;
  const map = [
    ['0%',   'transparent', ''],
    ['25%',  '#e84040',     'Weak'],
    ['50%',  '#e8a800',     'Fair'],
    ['75%',  '#6ec96e',     'Good'],
    ['100%', '#4caf7d',     'Strong ✓']
  ];
  fill.style.width      = map[score][0];
  fill.style.background = map[score][1];
  label.textContent     = map[score][2];
}

function getMechanic(vehicleType, address) {
  const db = ['bike','scooty','car'].includes(vehicleType)
    ? MX.mechanicsBike : MX.mechanicsOther;
  return db[address] || null;
}

function formatDate() {
  return new Date().toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' });
}

// ── SESSION (localStorage) ──
const Session = {
  set(key, val) { try { localStorage.setItem('mx_'+key, JSON.stringify(val)); } catch(e){} },
  get(key)      { try { return JSON.parse(localStorage.getItem('mx_'+key)); } catch(e){ return null; } },
  clear(key)    { localStorage.removeItem('mx_'+key); },
  isLoggedIn()  { return !!Session.get('user'); },
  isMechanic()  { return !!Session.get('mechanic'); }
};

// ── NAV TOGGLE (mobile) ──
function toggleNav() {
  const m = document.getElementById('mobileMenu');
  if (m) m.classList.toggle('open');
}

// ── Highlight active nav link ──
document.addEventListener('DOMContentLoaded', () => {
  const path = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-link').forEach(a => {
    const href = a.getAttribute('href').split('/').pop();
    if (href === path) a.classList.add('active');
    else a.classList.remove('active');
  });
});
